#!/usr/bin/env python3
"""
visualization.py — Versión corregida y estabilizada
"""

import matplotlib.pyplot as plt
import matplotlib.dates as mdates
import numpy as np
import pandas as pd
from pathlib import Path


# ============================================================
# CONTEXTO 2x2 — TMAX / TMEAN / TMIN / PR
# ============================================================


def plot_context_2x2(
    dfs,
    var_principal,
    estacion,
    fecha_obj,
    ventana,
    folder_out=None,
    show=True,
):
    var_principal = var_principal.lower()
    fecha_obj = pd.to_datetime(fecha_obj)

    variables = ["tmax", "tmean", "tmin", "pr"]
    unidades = {"tmax": "°C", "tmean": "°C", "tmin": "°C", "pr": "mm"}

    fig, axes = plt.subplots(2, 2, figsize=(12, 8), dpi=120)
    axes = axes.flatten()

    locator = mdates.AutoDateLocator()
    formatter = mdates.ConciseDateFormatter(locator)

    # -------------------------------------------------------
    # PANEL POR PANEL
    # -------------------------------------------------------
    for ax, var in zip(axes, variables):
        ax.set_title(f"{var.upper()} ({unidades[var]})")
        ax.grid(True, linestyle="--", alpha=0.4)

        df = dfs.get(var)
        if df is None or df.empty:
            _draw_empty_panel(ax)
            continue

        d = df.copy()
        d["fecha"] = pd.to_datetime(d["fecha"])
        d = d.sort_values("fecha")

        start = fecha_obj - pd.Timedelta(days=ventana)
        end = fecha_obj + pd.Timedelta(days=ventana)

        sub = d[(d["fecha"] >= start) & (d["fecha"] <= end)]

        if sub.empty:
            _draw_empty_panel(ax)
            continue

        fechas = sub["fecha"].values
        vals = sub["valor"].replace(-99, np.nan).astype(float).values

        # Caso sin datos válidos
        if np.all(np.isnan(vals)):
            _draw_empty_panel(ax)
            continue

        # Limites seguros
        vmin = np.nanmin(vals)
        vmax = np.nanmax(vals)
        rng = vmax - vmin if vmax > vmin else 1
        margin = 0.2 * rng

        ax.set_ylim(vmin - margin, vmax + margin)

        # PR = barras
        if var == "pr":
            ax.bar(fechas, np.nan_to_num(vals), width=0.8, color="#3A70E0", alpha=0.6)
        else:
            ax.plot(fechas, vals, "-o", markersize=4, linewidth=1.0, color="#004C99")

        # Fecha objetivo
        ax.axvline(fecha_obj, color="gray", linestyle="--", linewidth=1)

        # Punto objetivo si existe
        mask_fecha = sub["fecha"] == fecha_obj
        if mask_fecha.any():
            val = sub.loc[mask_fecha, "valor"].values[0]
            if val != -99 and not pd.isna(val):
                ax.scatter(
                    [fecha_obj], [val], s=90, color="red", edgecolor="black", zorder=5
                )

                # Offset vertical del texto
                v0, v1 = ax.get_ylim()
                yoff = 0.04 * (v1 - v0)
                ax.text(
                    fecha_obj,
                    val + yoff,
                    f"{float(val):.1f}",
                    ha="center",
                    va="bottom",
                    fontsize=8,
                    color="black",
                )

        # Fechas limpias
        ax.xaxis.set_major_locator(locator)
        ax.xaxis.set_major_formatter(formatter)
        ax.tick_params(axis="x", rotation=35, labelsize=8)

    fig.suptitle(
        f"Contexto {estacion} — {fecha_obj.strftime('%Y-%m-%d')} — {var_principal.upper()}",
        fontweight="bold",
        fontsize=14,
    )
    fig.tight_layout(rect=[0, 0, 1, 0.95])

    if folder_out:
        outdir = Path(folder_out) / "fig_contexto"
        outdir.mkdir(exist_ok=True)
        fname = (
            f"contexto_{estacion}_{var_principal}_{fecha_obj.strftime('%Y%m%d')}.png"
        )
        fig.savefig(outdir / fname, dpi=160, bbox_inches="tight")

    plt.show(block=False)
    return fig


# ============================================================
# PANEL VACÍO CONSISTENTE
# ============================================================


def _draw_empty_panel(ax):
    ax.set_xlim(-1, 1)
    ax.set_ylim(0, 1)
    ax.grid(True, linestyle="--", alpha=0.4)
    ax.text(
        0.5,
        0.5,
        "Sin datos",
        transform=ax.transAxes,
        ha="center",
        va="center",
        fontsize=10,
        color="gray",
    )


# ============================================================
# COMPARACIÓN ORG vs QC (2×1)
# ============================================================


def plot_comparison_qc(df_org, df_qc, var, periodo, estacion, folder_out):
    fig, axes = plt.subplots(2, 1, figsize=(12, 7), dpi=120, sharex=True)

    df_org = df_org.copy()
    df_qc = df_qc.copy()

    df_org["fecha"] = pd.to_datetime(df_org["fecha"])
    df_qc["fecha"] = pd.to_datetime(df_qc["fecha"])

    fechas = df_org["fecha"].values
    vo = df_org["valor"].replace(-99, np.nan).astype(float).values
    vq = df_qc["valor"].replace(-99, np.nan).astype(float).values

    locator = mdates.AutoDateLocator()
    formatter = mdates.ConciseDateFormatter(locator)

    # Panel original
    axes[0].plot(fechas, vo, "-", lw=0.7, color="gray", label="Original")
    axes[0].set_title("Serie Original")
    axes[0].grid(True, linestyle="--", alpha=0.4)
    axes[0].legend()

    # Panel corregido
    axes[1].plot(fechas, vq, "-", lw=0.9, color="#004C99", label="Corregida")

    mask_mod = ~np.isclose(vo, vq, equal_nan=True)
    if np.any(mask_mod):
        axes[1].scatter(
            fechas[mask_mod],
            vq[mask_mod],
            s=80,
            facecolors="none",
            edgecolors="red",
            linewidths=1.4,
            label="Modificado",
            zorder=5,
        )

    axes[1].set_title("Serie Corregida")
    axes[1].grid(True, linestyle="--", alpha=0.4)
    axes[1].legend()

    axes[1].xaxis.set_major_locator(locator)
    axes[1].xaxis.set_major_formatter(formatter)
    axes[1].tick_params(axis="x", rotation=35)

    fig.tight_layout()

    outdir = Path(folder_out) / "fig_comparacion"
    outdir.mkdir(parents=True, exist_ok=True)
    fname = f"{var}_{periodo}_{estacion}_comparacion.png"
    fig.savefig(outdir / fname, dpi=160, bbox_inches="tight")

    plt.close(fig)
