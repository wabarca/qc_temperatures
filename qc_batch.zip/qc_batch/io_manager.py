#!/usr/bin/env python3
"""
io_manager.py

Funciones para:
 - detectar archivo candidato (qc -> tmp -> org)
 - leer series CSV normalizando -99.0/-99.9 -> -99
 - escribir _tmp.csv y _qc.csv en folder_out
 - utilidades de nombres y listados

Uso:
  from io_manager import find_candidate_file, read_series, write_tmp, write_qc
"""

from pathlib import Path
import pandas as pd
import re
from typing import Optional, Dict, Any

# nombre esperado: var_periodo_estacion_org.csv
FNAME_RE = re.compile(
    r"^(?P<var>[^_]+)_(?P<periodo>[^_]+)_(?P<estacion>[^_]+?)(?:_(?P<suffix>org|tmp|qc))?\.csv$",
    re.IGNORECASE,
)


def parse_filename(fname: str) -> Optional[Dict[str, str]]:
    """Parsea nombre de archivo y devuelve dict con var, periodo, estacion, suffix (org/tmp/qc o None)"""
    m = FNAME_RE.match(Path(fname).name)
    if not m:
        return None
    return {k: (v.lower() if v else None) for k, v in m.groupdict().items()}


def build_filename(var: str, periodo: str, estacion: str, suffix: Optional[str]) -> str:
    """Construye nombre estandarizado; suffix uno de 'org','tmp','qc' o None (omitir)."""
    var = var.lower()
    periodo = periodo
    estacion = estacion
    if suffix:
        return f"{var}_{periodo}_{estacion}_{suffix}.csv"
    else:
        return f"{var}_{periodo}_{estacion}.csv"


def _safe_read_csv(path: Path) -> pd.DataFrame:
    """Lee CSV intentando detectar delimitador; devuelve DataFrame"""
    try:
        df = pd.read_csv(path, sep=None, engine="python")
    except Exception:
        # fallback: comma
        df = pd.read_csv(path)
    return df


def read_series(path: str) -> pd.DataFrame:
    """
    Lee CSV y devuelve DataFrame con columnas ['fecha','valor']:
      - convierte FECHA a datetime (formato YYYYMMDD preferido)
      - normaliza -99.0/-99.9 -> -99 (float)
      - ordena por fecha y resetea index
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"{path} no existe.")

    df = _safe_read_csv(p)
    # limpiar encabezados
    df.columns = [str(c).strip() for c in df.columns]

    if df.shape[1] < 2:
        raise ValueError(
            f"Archivo {p.name} debe tener al menos 2 columnas (fecha, valor)."
        )

    fecha_col = df.columns[0]
    val_col = df.columns[1]

    # convertir fecha (soporta YYYYMMDD y otras)
    df[fecha_col] = pd.to_datetime(
        df[fecha_col].astype(str), format="%Y%m%d", errors="coerce"
    )
    df = df.dropna(subset=[fecha_col]).reset_index(drop=True)

    # normalizar valores
    df[val_col] = pd.to_numeric(df[val_col], errors="coerce")
    df[val_col] = df[val_col].replace([-99.0, -99.9, -99.00], -99)
    df[val_col] = df[val_col].fillna(-99)

    out = pd.DataFrame({"fecha": df[fecha_col], "valor": df[val_col].astype(float)})
    out = out.sort_values("fecha").reset_index(drop=True)
    return out


def _ensure_outdir(folder_out: str):
    Path(folder_out).mkdir(parents=True, exist_ok=True)


def write_tmp(
    df: pd.DataFrame, folder_out: str, var: str, periodo: str, estacion: str
) -> str:
    """
    Guarda DataFrame como var_periodo_estacion_tmp.csv en folder_out.
    El dataframe debe tener columnas ['fecha','valor'] donde 'fecha' es datetime.
    Devuelve la ruta escrita.
    """
    _ensure_outdir(folder_out)
    fname = build_filename(var, periodo, estacion, "tmp")
    p = Path(folder_out) / fname
    df_out = df.copy()
    # formatear fecha a YYYYMMDD
    df_out["fecha"] = df_out["fecha"].dt.strftime("%Y%m%d")
    df_out.to_csv(p, index=False)
    return str(p)


def write_qc(
    df: pd.DataFrame, folder_out: str, var: str, periodo: str, estacion: str
) -> str:
    """
    Guarda DataFrame como var_periodo_estacion_qc.csv en folder_out.
    Devuelve la ruta escrita.
    """
    _ensure_outdir(folder_out)
    fname = build_filename(var, periodo, estacion, "qc")
    p = Path(folder_out) / fname
    df_out = df.copy()
    df_out["fecha"] = df_out["fecha"].dt.strftime("%Y%m%d")
    df_out.to_csv(p, index=False)
    return str(p)


def find_candidate_file(
    folder_in: str, folder_out: str, var: str, periodo: str, estacion: str
) -> Dict[str, Any]:
    """
    Busca y devuelve el candidato a usar para procesar la serie:
      prioridad: qc -> tmp -> org
    Retorna dict:
      {"status": "qc"|"tmp"|"org"|None, "path": "/abs/path" or None, "base_name": filename}
    """
    folder_in = Path(folder_in)
    folder_out = Path(folder_out)

    # nombres esperados
    fname_qc = build_filename(var, periodo, estacion, "qc")
    fname_tmp = build_filename(var, periodo, estacion, "tmp")
    fname_org = build_filename(var, periodo, estacion, "org")

    # 1) qc en folder_out
    p_qc = folder_out / fname_qc
    if p_qc.exists():
        return {"status": "qc", "path": str(p_qc), "base_name": p_qc.name}

    # 2) tmp en folder_out
    p_tmp = folder_out / fname_tmp
    if p_tmp.exists():
        return {"status": "tmp", "path": str(p_tmp), "base_name": p_tmp.name}

    # 3) org en folder_in
    p_org = folder_in / fname_org
    if p_org.exists():
        return {"status": "org", "path": str(p_org), "base_name": p_org.name}

    return {"status": None, "path": None, "base_name": ""}


def list_candidates(
    folder_in: str, folder_out: str, prefixes: Optional[list] = None
) -> list:
    """
    Lista archivos en folder_in que cumplan el patrón var_periodo_estacion_org.csv
    Retorna lista de dicts parseados con parse_filename
    """
    folder_in = Path(folder_in)
    files = []
    for f in sorted(folder_in.glob("*.csv")):
        parsed = parse_filename(f.name)
        if not parsed:
            continue
        # solo incluir archivos con sufijo org o sin sufijo (para compatibilidad)
        # consideramos var en allowed si se pasa prefixes
        if prefixes and parsed["var"] not in prefixes:
            continue
        files.append({"path": str(f), **parsed})
    return files
