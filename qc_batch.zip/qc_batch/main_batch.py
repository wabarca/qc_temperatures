#!/usr/bin/env python3
"""
main_batch.py

Ejecutor principal del sistema de QC en lote.
Escanea la carpeta de entrada en busca de archivos *_org.csv,
pregunta qué hacer si existen versiones TMP o QC,
y llama al workflow para procesar cada archivo.

Menú igual al estilo clásico del código original:

  (s) Omitir y marcar como COMPLETADO
  (n) Revisar nuevamente desde cero
  (p) Posponer — omitir solo en esta ejecución
  (r) Reanudar desde versión temporal (TMP)

"""

import argparse
import os
from pathlib import Path
import re
from qc_batch.io_manager import parse_filename, build_filename
from qc_batch.workflow import process_file


# ---------------------------------------------------------------------
# Buscar archivos *_org.csv en la carpeta de entrada
# ---------------------------------------------------------------------
def buscar_archivos_org(folder_in: str):
    folder = Path(folder_in)
    archivos = []

    for f in folder.glob("*_org.csv"):
        info = parse_filename(f.name)
        if info is None:
            continue
        archivos.append(
            {
                "path": f,
                "var": info["var"],
                "periodo": info["periodo"],
                "estacion": info["estacion"],
            }
        )

    return archivos


# ---------------------------------------------------------------------
# Menú clásico (opción B)
# ---------------------------------------------------------------------
def menu_interactivo(archivo, existe_tmp, existe_qc):
    """Menú interactivo estilo clásico."""

    print("\n===========================================")
    print(f"Procesando archivo: {archivo}")
    print("===========================================\n")

    if existe_qc:
        print("⚠️  Se encontró una versión QC previa para este archivo.")
    elif existe_tmp:
        print("⚠️  Se encontró una versión TEMPORAL (TMP) para este archivo.")

    # Menú clásico igual al código previo
    print("\n¿Qué desea hacer?\n")
    print("  (s) Omitir y marcar como COMPLETADO")
    print("  (n) Revisar nuevamente desde cero")
    print("  (p) Posponer — omitir solo en esta ejecución")
    print("  (r) Reanudar desde versión temporal (TMP)\n")

    while True:
        resp = input("Elija opción: ").strip().lower()

        if resp in ("s", "n", "p", "r"):
            return resp

        print("❌ Opción inválida. Intente nuevamente.\n")


# ---------------------------------------------------------------------
# Ejecución principal por archivo
# ---------------------------------------------------------------------
def procesar_archivo(entry, folder_in, folder_out, ventana, lower_p, upper_p, k):
    var = entry["var"]
    periodo = entry["periodo"]
    estacion = entry["estacion"]

    # Detectar si existen tmp o qc
    fname_tmp = build_filename(var, periodo, estacion, "tmp")
    fname_qc = build_filename(var, periodo, estacion, "qc")

    existe_tmp = Path(folder_out, fname_tmp).exists()
    existe_qc = Path(folder_out, fname_qc).exists()

    # Mostrar menú clásico y pedir acción
    accion = menu_interactivo(
        archivo=entry["path"].name, existe_tmp=existe_tmp, existe_qc=existe_qc
    )

    # Procesar según acción
    if accion == "s":
        # marcar como completado sin procesar
        print(f"✔ Marcado como COMPLETADO: {entry['path'].name}\n")
        return

    if accion == "p":
        # Omitir solo esta vez
        print(f"⏭ Omitido en esta ejecución: {entry['path'].name}\n")
        return

    if accion == "n":
        # Procesar desde cero: ignorar tmp o qc
        print(f"🔄 Procesando desde cero: {entry['path'].name}\n")
        process_file(
            var=var,
            periodo=periodo,
            estacion=estacion,
            folder_in=folder_in,
            folder_out=folder_out,
            lower_p=lower_p,
            upper_p=upper_p,
            k=k,
            ventana=ventana,
            ask_user=input,
        )
        return

    if accion == "r":
        # Reanudar desde tmp
        if existe_tmp:
            print(f"🔁 Reanudando desde TMP: {entry['path'].name}\n")
        else:
            print("⚠️ No existe TMP, procesando desde cero.\n")

        process_file(
            var=var,
            periodo=periodo,
            estacion=estacion,
            folder_in=folder_in,
            folder_out=folder_out,
            lower_p=lower_p,
            upper_p=upper_p,
            k=k,
            ventana=ventana,
            ask_user=input,
        )
        return


# ---------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser(
        description="Ejecutor en lote del control de calidad de series climáticas."
    )

    parser.add_argument(
        "-i", "--input", required=True, help="Carpeta de entrada que contiene *_org.csv"
    )

    parser.add_argument(
        "-o", "--output", required=True, help="Carpeta de salida para guardar tmp y qc"
    )

    parser.add_argument(
        "--ventana",
        type=int,
        default=7,
        help="Días hacia atrás y adelante para la gráfica de contexto (default: 7)",
    )

    parser.add_argument(
        "--lower-p",
        type=float,
        default=0.1,
        help="Percentil inferior para control estadístico (default: 0.1)",
    )

    parser.add_argument(
        "--upper-p",
        type=float,
        default=0.9,
        help="Percentil superior para control estadístico (default: 0.9)",
    )

    parser.add_argument(
        "-k", type=float, default=1.5, help="Multiplicador del IQR (default: 1.5)"
    )

    args = parser.parse_args()

    folder_in = args.input
    folder_out = args.output
    ventana = args.ventana

    lower_p = args.lower_p
    upper_p = args.upper_p
    k = args.k

    # Buscar archivos ORG
    entradas = buscar_archivos_org(folder_in)

    if not entradas:
        print("❌ No se encontraron archivos *_org.csv en la carpeta de entrada.")
        return

    print(f"\n🔍 Detectados {len(entradas)} archivos para procesar.\n")

    # Procesar cada archivo
    for entry in entradas:
        var = entry["var"].lower()

        # OMITIR variables no térmicas
        if var not in ("tmin", "tmean", "tmax"):
            print(f"⏭ Omitiendo variable no térmica: {var}")
            continue
        procesar_archivo(entry, folder_in, folder_out, ventana, lower_p, upper_p, k)


if __name__ == "__main__":
    main()
