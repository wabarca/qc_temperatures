#!/usr/bin/env python3
"""
helpers_compare.py

Comparación interactiva con otras estaciones (estilo código original).
"""

from pathlib import Path
import pandas as pd
from qc_batch.io_manager import find_candidate_file, read_series
from qc_batch.visualization import plot_context_2x2


def compare_with_other_station(
    var: str,
    periodo: str,
    estacion_actual: str,
    fecha_obj,
    folder_in: str,
    folder_out: str,
    ventana: int,
    ask_user=input,
):
    """
    Pregunta si se desea comparar con otra estación.
    Carga la serie equivalente, encuentra la fecha más cercana, muestra 2x2 NO bloqueante.
    """

    fecha_obj = pd.to_datetime(fecha_obj)

    while True:
        resp = (
            ask_user("¿Desea comparar con otra estación para el mismo día? (s/n): ")
            .strip()
            .lower()
        )
        if resp not in ("s", "y"):
            return

        estacion_comp = ask_user("Ingrese el ID de la estación (ej. S-12): ").strip()
        if not estacion_comp:
            print("⚠ Código vacío.")
            continue

        # Buscar archivo equivalente
        info = find_candidate_file(folder_in, folder_out, var, periodo, estacion_comp)
        path = info.get("path")

        if not path or not Path(path).exists():
            print(
                f"⚠ No se encontró archivo para {var.upper()} en estación {estacion_comp}."
            )
            continue

        # Cargar serie
        df_aux = read_series(path).copy()
        df_aux["fecha"] = pd.to_datetime(df_aux["fecha"])

        # Fecha más cercana
        idx = (df_aux["fecha"] - fecha_obj).abs().idxmin()
        fecha_real = df_aux.loc[idx, "fecha"]

        dfs = {var: df_aux}

        # Mostrar comparativa
        plot_context_2x2(
            dfs,
            var_principal=var,
            estacion=estacion_comp,
            fecha_obj=fecha_real,
            ventana=ventana,
            folder_out=None,
            show=True,
        )

        print(f"🟢 Comparativa abierta para estación {estacion_comp}.\n")
