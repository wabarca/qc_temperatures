#!/usr/bin/env python3
"""
workflow.py

Flujo completo del control de calidad de temperaturas.
Incluye:

 - Detección de archivo base (org/tmp/qc)
 - Control termodinámico interactivo
 - Control estadístico
 - Gráficas en contexto (tmax, tmean, tmin, pr)
 - Comparación manual con otras estaciones
 - Escritura _tmp y _qc
 - Archivo auxiliar *_changes.csv
 - Generación de reportes PDF
"""

from pathlib import Path
import pandas as pd
import json

from qc_batch.io_manager import (
    find_candidate_file,
    read_series,
    write_tmp,
    write_qc,
    build_filename,
)
from qc_batch.thermo_qc import (
    load_triplet,
    detect_thermal_inconsistencies,
    apply_thermal_correction,
    write_triplet_tmp,
)
from qc_batch.stat_qc import compute_bounds, detect_outliers, apply_statistical_decision
from qc_batch.visualization import plot_context_2x2, plot_comparison_qc
from qc_batch.helpers_compare import compare_with_other_station
from qc_batch.modifications import build_changes_dataframe, save_changes_csv
from qc_batch.report import generar_informe_pdf


# ================================================================
#  Registrar archivo completado
# ================================================================


def mark_completed(folder_out: str, filename: str):
    path = Path(folder_out) / "completed_series.json"

    if not path.exists():
        data = {"completadas": []}
    else:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except:
            data = {"completadas": []}

    if filename not in data["completadas"]:
        data["completadas"].append(filename)

    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


# ================================================================
#  Función principal
# ================================================================


def process_file(
    var: str,
    periodo: str,
    estacion: str,
    folder_in: str,
    folder_out: str,
    lower_p: float = 0.1,
    upper_p: float = 0.9,
    k: float = 1.5,
    ventana: int = 7,
    ask_user=None,
):
    """
    Procesa una variable para una estación específica.
    """

    if ask_user is None:
        ask_user = input

    # Excluir variables NO térmicas (solo pr)
    if var.lower() not in ("tmax", "tmean", "tmin"):
        print(f"⏭ Omitiendo variable no térmica: {var}")
        return

    # Archivo base
    base_info = find_candidate_file(folder_in, folder_out, var, periodo, estacion)
    status = base_info["status"]
    path_base = base_info["path"]

    if status is None:
        print(f"No se encontró archivo para {var}_{periodo}_{estacion}")
        return

    print(f"[{var.upper()}] Archivo base detectado: {status.upper()} → {path_base}")

    # Leer ORG para comparativa final
    path_org = Path(folder_in) / build_filename(var, periodo, estacion, "org")
    df_org = read_series(path_org)

    # =========================================================
    # CONTROL TERMODINÁMICO
    # =========================================================
    dfs_trip = load_triplet(folder_in, folder_out, periodo, estacion)

    inconsist = detect_thermal_inconsistencies(
        dfs_trip["tmin"], dfs_trip["tmean"], dfs_trip["tmax"]
    )

    for inc in inconsist:
        fecha = pd.to_datetime(inc["fecha"])
        tipo = inc["tipo"]

        print(f"\nInconsistencia térmica en {fecha.date()} → {tipo}")

        # Gráfica de contexto (no bloqueante)
        fig = plot_context_2x2(
            dfs_trip,
            var_principal=var,
            estacion=estacion,
            fecha_obj=fecha,
            ventana=ventana,
            folder_out=folder_out,
            show=True,
        )

        # Comparación manual por ID
        compare_with_other_station(
            var, periodo, estacion, fecha, folder_in, folder_out, ventana, ask_user
        )

        # Mostrar menú detallado
        print("\nAcciones térmicas:")
        print("  (i) Intercambiar tmax ↔ tmin")
        print("  (t) Poner solo tmean en -99")
        print("  (x) Poner tmean y la variable afectada en -99")
        print("  (e) Editar manualmente los 3 valores")
        print("  (s) Sustituir los 3 por -99")
        print("  (m) Mantener valores")
        print("  (r) Reordenar automáticamente (tmin < tmean < tmax)\n")

        # Acción térmica
        while True:
            action = (
                ask_user(f"Acción para {fecha.date()} ({tipo}) [i/t/x/e/s/m/r]: ")
                .strip()
                .lower()
            )
            if action in ("i", "t", "x", "e", "s", "m", "r"):
                break
            print("❌ Acción inválida.")

        plt.close(fig)  # cerrar figura antes de aplicar cambios

        dfs_trip = apply_thermal_correction(
            action, fecha, dfs_trip, folder_out, estacion, periodo
        )

    # Guardar *_tmp.csv
    write_triplet_tmp(dfs_trip, folder_out, periodo, estacion)

    # DF base de la variable
    dfs_trip = load_triplet(folder_in, folder_out, periodo, estacion)
    df_base = dfs_trip[var]

    # =========================================================
    # CONTROL ESTADÍSTICO
    # =========================================================
    serie_valida = df_base[df_base["valor"] != -99]["valor"]
    bounds = compute_bounds(serie_valida, lower_p=lower_p, upper_p=upper_p, k=k)
    outliers = detect_outliers(df_base, bounds)

    for idx, val in outliers:
        fecha = df_base.loc[idx, "fecha"]

        print(f"\nOutlier estadístico en {fecha.date()} → {val}")

        # Mostrar contexto completo
        fig = plot_context_2x2(
            load_triplet(folder_in, folder_out, periodo, estacion),
            var_principal=var,
            estacion=estacion,
            fecha_obj=fecha,
            ventana=ventana,
            folder_out=folder_out,
            show=True,
        )

        # Comparación por ID
        compare_with_other_station(
            var, periodo, estacion, fecha, folder_in, folder_out, ventana, ask_user
        )

        # Menú estadístico
        print("\nAcciones estadísticas:")
        print("  (s) Sustituir por -99")
        print("  (m) Mantener valor original")
        print("  (n) Ingresar nuevo valor\n")

        while True:
            decision = (
                ask_user(
                    f"Acción estadística para {fecha.date()} valor={val} [s/m/n]: "
                )
                .strip()
                .lower()
            )

            if decision in ("s", "m", "n"):
                break
            print("❌ Acción inválida.")

        plt.close(fig)

        if decision == "n":
            new_val = float(ask_user(f"Nuevo valor para {fecha.date()}: ").strip())
            df_base = apply_statistical_decision(df_base, idx, "n", new_val)
        else:
            df_base = apply_statistical_decision(df_base, idx, decision)

    # =========================================================
    # GUARDAR ARCHIVO QC
    # =========================================================
    path_qc = write_qc(df_base, folder_out, var, periodo, estacion)
    print(f"\n✔ Archivo QC generado: {path_qc}")

    mark_completed(folder_out, Path(path_qc).name)

    # =========================================================
    # ARCHIVO DE CAMBIOS
    # =========================================================
    df_changes = build_changes_dataframe(df_org, df_base, folder_out)
    path_changes = save_changes_csv(df_changes, folder_out, var, periodo, estacion)
    print(f"📄 Archivo de cambios generado: {path_changes}")

    # =========================================================
    # GRÁFICA COMPARATIVA
    # =========================================================
    plot_comparison_qc(df_org, df_base, var, periodo, estacion, folder_out)

    # =========================================================
    # INFORME PDF
    # =========================================================
    generar_informe_pdf(folder_out, var, periodo, estacion, df_changes)

    print(f"\n🎉 [OK] QC COMPLETADO para {var.upper()} en estación {estacion}.\n")
